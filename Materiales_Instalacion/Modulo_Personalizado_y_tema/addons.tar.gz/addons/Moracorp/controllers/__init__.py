# -*- coding: utf-8 -*-
from . import apirest
from . import productos_controller
from . import ventas_controller
from . import compras_controller
from . import stock_controller
from . import proveedores_controller
from . import clientes_controller
from . import pedidos_controller
from . import borrar_controller
from . import editar_controller
from . import transaccion_venta_controller